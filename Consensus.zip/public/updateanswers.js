fusionapi = "https://www.googleapis.com/fusiontables/v1/query?sql=SELECT%20*%20FROM%201RenyfBpnH9qDuCwnLsJS5gXFBizRX0i2iTp0AK3y&key=AIzaSyDaqGYgg7-5z8d1i1CT4O43jHGrfBKa5pM"

sql 
sql UPDATE guesses